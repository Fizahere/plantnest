<?php

$server = 'mysql:host=localhost;dbname=plantnest';
$user = 'root';
$password = '';

$pdo = new PDO($server,$user,$password);

?>