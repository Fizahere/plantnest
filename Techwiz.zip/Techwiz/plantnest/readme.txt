#PlantNest

Admin Login: ``
http://localhost/Techwiz/adminPanel/signin.php
----

admin@gmail.com
1234

----

User Login: ``
http://localhost/techwiz/plantfy/login.php
----

user@gmail.com
1234

online webhost link
Link:
Password: plantFy_123