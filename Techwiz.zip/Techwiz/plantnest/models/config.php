<?php

include_once('php/connection.php');
include_once('php/functions.php');

function getRoot()
{
    return '/Techwiz/plantnest/';
}

?>